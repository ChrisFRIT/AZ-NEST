# Description

>NOTE: The **xWebConfigKeyValue** resource is deprecated and has been replaced by the **xWebConfigProperty** and **xWebConfigPropertyCollection** resources.
>It may be removed in a future release.

## Requirements

* Target machine must be running Windows Server 2012 R2 or later.

## Known issues

All issues are not listed here, see [here for all open issues](https://github.com/dsccommunity/xWebAdministration/issues?q=is%3Aissue+is%3Aopen+in%3Atitle+xWebConfigKeyValue).
