Configuration WindowsWebServer {

    Import-DscResource -ModuleName PSDesiredStateConfiguration, xWebAdministration

    Node localhost {

        WindowsFeature WebServerRole
        {
		    Name = "Web-Server"
		    Ensure = "Present"
        }

        WindowsFeature WebManagementConsole
        {
            Name = "Web-Mgmt-Console"
            Ensure = "Present"
        }

        WindowsFeature WebManagementService
        {
            Name = "Web-Mgmt-Service"
            Ensure = "Present"
        }

        WindowsFeature ASPNet45
        {
		    Ensure = "Present"
		    Name = "Web-Asp-Net45"
        }

        WindowsFeature HTTPRedirection
        {
            Name = "Web-Http-Redirect"
            Ensure = "Present"
        }

        WindowsFeature CustomLogging
        {
            Name = "Web-Custom-Logging"
            Ensure = "Present"
        }

        WindowsFeature LogginTools
        {
            Name = "Web-Log-Libraries"
            Ensure = "Present"
        }

        WindowsFeature RequestMonitor
        {
            Name = "Web-Request-Monitor"
            Ensure = "Present"
        }

        WindowsFeature Tracing
        {
            Name = "Web-Http-Tracing"
            Ensure = "Present"
        }

        WindowsFeature BasicAuthentication
        {
            Name = "Web-Basic-Auth"
            Ensure = "Present"
        }

        WindowsFeature WindowsAuthentication
        {
            Name = "Web-Windows-Auth"
            Ensure = "Present"
        }

        WindowsFeature ApplicationInitialization
        {
            Name = "Web-AppInit"
            Ensure = "Present"
        }

        WindowsFeature IISManagement  
        {  
            Ensure          = 'Present'
            Name            = 'Web-Mgmt-Console'
            DependsOn       = '[WindowsFeature]WebServerRole'
        } 

		xIisLogging Logging
        {
			LogPath				 = 'C:\inetpub\logs\LogFiles'
            Logflags             = @('Date','Time','ClientIP','UserName','SiteName','ComputerName','ServerIP','ServerPort','Method','UriStem','UriQuery','HttpStatus','HttpSubStatus','Win32Status','BytesSent','BytesRecv','TimeTaken','ProtocolVersion','Host','UserAgent','Referer')
            LoglocalTimeRollover = $true
            LogPeriod            = 'Daily'
            LogFormat            = 'W3C'
			LogCustomFields    = @(
                MSFT_xLogCustomField
                {
                    LogFieldName = 'Content-Type'
                    SourceName   = 'Content-Type'
                    SourceType   = 'RequestHeader'
                }
                MSFT_xLogCustomField
                {
                    LogFieldName = 'X-Forwarded-For'
                    SourceName   = 'X-Forwarded-For'
                    SourceType   = 'RequestHeader'
                }
			)
        }
		
		xWebSiteDefaults SiteDefaults
        {
            IsSingleInstance       = 'Yes'
            LogFormat              = 'W3C'
            LogDirectory           = 'C:\inetpub\logs\LogFiles'
            TraceLogDirectory      = 'C:\inetpub\logs\FailedReqLogFiles'
            DefaultApplicationPool = 'DefaultAppPool'
            AllowSubDirConfig      = 'true'
        }
		
		#xWebConfigProperty
        #{
        #    Filter       = 'system.webServer/security/requestFiltering'
        #    PropertyName = 'removeServerHeader'
        #    Value        = 'true'
        #    Ensure       = 'Present'
        #}
	}
}